const $=id=>document.getElementById(id);
const todayKey=()=>new Date().toISOString().slice(0,10);
let state=JSON.parse(localStorage.getItem("foinTracker")||"{}");
if(!state.days)state.days={}; if(!state.current)state.current=null; if(!state.theme)state.theme="light";
function trips(){let k=todayKey(); if(!state.days[k])state.days[k]=[]; return state.days[k];}
function save(){localStorage.setItem("foinTracker",JSON.stringify(state));}
function time(x){return new Date(x).toLocaleTimeString("fr-CA",{hour:"2-digit",minute:"2-digit"});}
function dur(ms){let m=Math.round(ms/60000); return m<60?m+" min":Math.floor(m/60)+" h "+String(m%60).padStart(2,"0");}
function vib(){if(navigator.vibrate)navigator.vibrate(80);}
function render(){
document.body.className=state.theme==="dark"?"dark":"";
$("dateLabel").textContent=new Date().toLocaleDateString("fr-CA",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
let list=trips(), totalBales=list.reduce((s,t)=>s+t.bales,0), totalMs=list.reduce((s,t)=>s+(t.end-t.start),0);
$("tripCount").textContent=list.length; $("baleTotal").textContent=totalBales; $("avgTime").textContent=list.length?dur(totalMs/list.length):"0 min"; $("totalTime").textContent=totalMs?dur(totalMs):"0 min";
$("mainBtn").textContent=state.current?"🏁 ARRIVÉE":"🚜 DÉPART"; $("mainBtn").className=state.current?"main arrive":"main start";
$("activeTrip").classList.toggle("hidden",!state.current); if(state.current)$("startedAt").textContent="Départ à "+time(state.current.start);
let h=$("historyList"); h.innerHTML=""; if(!list.length){h.innerHTML='<div class="empty">Aucun voyage enregistré aujourd’hui.</div>';return;}
[...list].reverse().forEach((t,i)=>{let n=list.length-i; h.innerHTML+=`<div class="item"><b>Voyage ${n} — ${t.bales} balles</b><small>${time(t.start)} → ${time(t.end)} • ${dur(t.end-t.start)}</small></div>`;});
}
function tick(){if(state.current){let sec=Math.floor((Date.now()-state.current.start)/1000);$("elapsed").textContent=String(Math.floor(sec/60)).padStart(2,"0")+":"+String(sec%60).padStart(2,"0");}}
setInterval(tick,1000);
$("mainBtn").onclick=()=>{if(!state.current){state.current={start:Date.now()};save();vib();render();tick();}else{$("balePicker").classList.remove("hidden");}};
$("cancelArrival").onclick=()=>$("balePicker").classList.add("hidden");
for(let i=1;i<=20;i++){let b=document.createElement("button");b.textContent=i;b.onclick=()=>{trips().push({start:state.current.start,end:Date.now(),bales:i});state.current=null;$("balePicker").classList.add("hidden");save();vib();render();};$("baleGrid").appendChild(b);}
$("undoBtn").onclick=()=>{let l=trips();if(!l.length)return alert("Aucun voyage à annuler.");if(confirm("Annuler le dernier voyage?")){l.pop();save();render();}};
$("newDayBtn").onclick=()=>{if(confirm("Effacer les voyages d’aujourd’hui?")){state.days[todayKey()]=[];state.current=null;save();render();}};
$("themeBtn").onclick=()=>{state.theme=state.theme==="dark"?"light":"dark";save();render();};
$("exportBtn").onclick=()=>{let rows=[["Date","Depart","Arrivee","Duree_minutes","Balles"]];trips().forEach(t=>rows.push([todayKey(),time(t.start),time(t.end),Math.round((t.end-t.start)/60000),t.bales]));let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([rows.map(r=>r.join(",")).join("\n")],{type:"text/csv"}));a.download="foin-tracker-"+todayKey()+".csv";a.click();};
render();tick();
if("serviceWorker" in navigator)navigator.serviceWorker.register("sw.js");
